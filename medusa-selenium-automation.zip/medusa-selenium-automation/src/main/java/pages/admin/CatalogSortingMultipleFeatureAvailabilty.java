package pages.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import utility.HOOKS;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CatalogSortingMultipleFeatureAvailabilty extends HOOKS {

    By productsButtonPath = By.xpath("//a[@href='/app/products'] ");
    By sortByDropdownPath = By.xpath("//button[@aria-haspopup='menu' and contains(@class, 'shadow-buttons-neutral')]");
    By selectFeatureAvailabilityOptionPath = By.xpath("//div[@role='menuitemradio' and contains(text(),'Descending')]");
    By selectFeatureAvailabilityOption2Path = By.xpath("//div[@role='menuitemradio' and text()='Title']");
    By productTitlesPath = By.xpath("//td[contains(@class, 'sticky')]//span[@title][@class='truncate']");

    public void clickProductsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(productsButtonPath));
        WebElement productsButton = driver.findElement(productsButtonPath);
        productsButton.click();
    }

    public void clickSortByDropdown() throws InterruptedException {
        WebElement sortByDropdown = wait.until(ExpectedConditions.elementToBeClickable(sortByDropdownPath));
        sortByDropdown.click();
    }

    public void selectFeatureAvailabilityOption() {
        WebElement featureAvailabilityOption = wait.until(ExpectedConditions.elementToBeClickable(selectFeatureAvailabilityOptionPath));
        featureAvailabilityOption.click();
    }

    public void selectFeatureAvailabilityOption2() throws InterruptedException {
        WebElement featureAvailabilityOption2 = wait.until(ExpectedConditions.elementToBeClickable(selectFeatureAvailabilityOption2Path));
        featureAvailabilityOption2.click();
        featureAvailabilityOption2.sendKeys(Keys.ESCAPE);
    }

    public boolean verifyProductsSortedByTitleDescending() {
        try {
            wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(productTitlesPath));

            List<WebElement> productElements = driver.findElements(productTitlesPath);

            if (productElements.size() < 2) {
                System.out.println("Not enough products to verify sorting (found: " + productElements.size() + ")");
                return false;
            }

            List<String> actualTitles = new ArrayList<>();
            for (WebElement element : productElements) {
                String title = element.getAttribute("title");
                if (title != null && !title.trim().isEmpty()) {
                    actualTitles.add(title.trim());
                }
            }

            List<String> expectedTitles = new ArrayList<>(actualTitles);
            Collections.sort(expectedTitles, String.CASE_INSENSITIVE_ORDER.reversed());

            // debugging
            System.out.println("Actual order: " + actualTitles);
            System.out.println("Expected order: " + expectedTitles);

            // compare actual vs expected
            boolean isSorted = actualTitles.equals(expectedTitles);

            if (!isSorted) {
                System.out.println("Products are NOT sorted correctly!");
                for (int i = 0; i < actualTitles.size(); i++) {
                    if (!actualTitles.get(i).equals(expectedTitles.get(i))) {
                        System.out.println("Mismatch at position " + i + ": " +
                                "Expected '" + expectedTitles.get(i) + "' but found '" + actualTitles.get(i) + "'");
                    }
                }
            }

            return isSorted;

        }
        catch (Exception e) {
            System.out.println("Error verifying product sorting: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public int getProductCount() {
        try {
            List<WebElement> products = driver.findElements(productTitlesPath);
            return products.size();
        } catch (Exception e) {
            return 0;
        }
    }

}
