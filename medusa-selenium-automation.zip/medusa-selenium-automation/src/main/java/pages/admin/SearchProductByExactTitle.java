package pages.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import utility.HOOKS;

import java.time.Duration;

public class SearchProductByExactTitle extends HOOKS {

    By productsButtonPath = By.xpath("//a[@href='/app/products'] ");
    By searchFieldPath = By.name("q");
    By productTitlePath = By.xpath("//span[@title='Medusa Sweatshirt']");


    public void clickProductsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(productsButtonPath));
        WebElement productsButton = driver.findElement(productsButtonPath);
        productsButton.click();
    }

    public void enterSearchQuery(String query) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchFieldPath));
        WebElement searchField = driver.findElement(searchFieldPath);
        searchField.clear();
        searchField.sendKeys(query);
    }

    public boolean isProductDisplayed(String productName) {
        By productLocator = By.xpath("//span[@title='" + productName + "']");
        try {
            WebElement product = wait.until(ExpectedConditions.visibilityOfElementLocated(productLocator));
            return product.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public String getProductTitle() {
        WebElement productTitle = wait.until(ExpectedConditions.visibilityOfElementLocated(productTitlePath));
        return productTitle.getText();
    }

}
