package pages.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import utility.HOOKS;

public class DeleteProductFromAdminPanel extends HOOKS {

    By productsButtonPath = By.xpath("//a[@href='/app/products'] ");
    By threeDotMenuButtonPath = By.xpath("//tr[.//span[text()='Delete Product']]//button[@aria-haspopup='menu' and contains(@class, 'bg-ui-button-transparent')]");
    By deleteMenuItemPath = By.xpath("//div[@role='menuitem']//span[text()='Delete']");
    By confirmDeleteButton = By.xpath("//div[@role='alertdialog']//button[text()='Delete']");

    public void clickProductsButton() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(productsButtonPath));
        WebElement productsButton = driver.findElement(productsButtonPath);
        productsButton.click();
        Thread.sleep(2000);
    }

    public void clickOnThreeDotMenuButton() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(threeDotMenuButtonPath));
        WebElement threeDotMenuButton = driver.findElement(threeDotMenuButtonPath);
        threeDotMenuButton.click();
        Thread.sleep(2000);
    }

    public void clickOnDeleteMenuItem() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(deleteMenuItemPath));
        WebElement deleteMenuItem = driver.findElement(deleteMenuItemPath);
        deleteMenuItem.click();
        Thread.sleep(2000);
    }

    public void clickOnConfirmDeleteButton() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(confirmDeleteButton));
        WebElement confirmDeleteBtn = driver.findElement(confirmDeleteButton);
        confirmDeleteBtn.click();
        Thread.sleep(2000);
    }

}
