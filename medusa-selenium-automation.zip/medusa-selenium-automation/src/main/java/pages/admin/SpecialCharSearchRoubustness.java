package pages.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import utility.HOOKS;

import java.util.ArrayList;
import java.util.List;

public class SpecialCharSearchRoubustness extends HOOKS {

    By productsButtonPath = By.xpath("//a[@href='/app/products']");
    By searchFieldPath = By.name("q");
    By allProductTitlesPath = By.xpath("//td[contains(@class, 'sticky')]//span[@title][@class='truncate']");
    By productsHeaderPath = By.xpath("//h1[text()='Products']");
    By errorMessagePath = By.xpath("//div[contains(@class, 'error')] | //div[contains(@class, 'alert')] | //span[contains(text(), 'error')]");

    public void clickProductsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(productsButtonPath));
        WebElement productsButton = driver.findElement(productsButtonPath);
        productsButton.click();
    }

    public void enterSearchQuery(String query) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchFieldPath));
        WebElement searchField = driver.findElement(searchFieldPath);
        searchField.clear();
        searchField.sendKeys(query);
    }

    // Get count of displayed products
    public int getProductCount() {
        try {
            Thread.sleep(500);
            List<WebElement> products = driver.findElements(allProductTitlesPath);
            int count = products.size();
            System.out.println("Current product count: " + count);
            return count;
        } catch (Exception e) {
            System.out.println("Error getting product count: " + e.getMessage());
            return 0;
        }
    }

    // Check if page is still loaded
    public boolean isPageLoaded() {
        try {
            WebElement header = driver.findElement(productsHeaderPath);
            return header.isDisplayed();
        } catch (Exception e) {
            System.out.println("Page not loaded properly: " + e.getMessage());
            return false;
        }
    }

    // Check if search field is accessible
    public boolean isSearchFieldAccessible() {
        try {
            WebElement searchField = driver.findElement(searchFieldPath);
            return searchField.isDisplayed() && searchField.isEnabled();
        } catch (Exception e) {
            System.out.println("Search field not accessible: " + e.getMessage());
            return false;
        }
    }

    // Check if there's an error message
    public boolean hasErrorMessage() {
        try {
            List<WebElement> errorElements = driver.findElements(errorMessagePath);
            if (!errorElements.isEmpty()) {
                for (WebElement error : errorElements) {
                    if (error.isDisplayed()) {
                        System.out.println("Error message found: " + error.getText());
                        return true;
                    }
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    // Check if application is responsive
    public boolean isApplicationResponsive() {
        try {
            // Try to interact with the search field
            WebElement searchField = driver.findElement(searchFieldPath);
            searchField.isEnabled();

            // Check if products section is visible
            boolean pageVisible = isPageLoaded();

            // Check if we can find the products table/list structure
            By tableOrListPath = By.xpath("//table | //div[contains(@class, 'flex-col')]");
            WebElement contentArea = driver.findElement(tableOrListPath);

            return pageVisible && contentArea.isDisplayed();
        } catch (Exception e) {
            System.out.println("Application may not be responsive: " + e.getMessage());
            return false;
        }
    }

}