package pages.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import utility.HOOKS;

import java.util.ArrayList;
import java.util.List;

public class FilterProductsByStatusDraft extends HOOKS {

    By productsButtonPath = By.xpath("//a[@href='/app/products']");
    By addFilterPath = By.id("filters_menu_trigger");
    By statusPath = By.xpath("//div[@role='menuitem' and text()='Status']");
    By draftStatusPath = By.cssSelector("[data-value='draft']");

    // Locators for verification
    By allProductTitlesPath = By.xpath("//td[contains(@class, 'sticky')]//span[@title][@class='truncate']");
    By allProductStatusPath = By.xpath("//td//span[@class='truncate' and (text()='Draft' or text()='Published')]");

    public void clickProductsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(productsButtonPath));
        WebElement productsButton = driver.findElement(productsButtonPath);
        productsButton.click();
    }

    public void clickAddFilter() {
        wait.until(ExpectedConditions.elementToBeClickable(addFilterPath));
        WebElement addFilterButton = driver.findElement(addFilterPath);
        addFilterButton.click();
    }

    public void selectStatusFilter() {
        wait.until(ExpectedConditions.elementToBeClickable(statusPath));
        WebElement statusFilter = driver.findElement(statusPath);
        statusFilter.click();
    }

    public void selectDraftStatus() {
        wait.until(ExpectedConditions.elementToBeClickable(draftStatusPath));
        WebElement draftStatusOption = driver.findElement(draftStatusPath);
        draftStatusOption.click();
        driver.findElement(By.tagName("body")).sendKeys(org.openqa.selenium.Keys.ESCAPE);
    }

    // Get count of displayed products
    public int getProductCount() {
        try {
            Thread.sleep(500); // Small wait for products to load
            wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(allProductTitlesPath));
            List<WebElement> products = driver.findElements(allProductTitlesPath);
            int count = products.size();
            System.out.println("Current product count: " + count);
            return count;
        } catch (Exception e) {
            System.out.println("Error getting product count: " + e.getMessage());
            return 0;
        }
    }

    // Verify all products have the specified status
    public boolean verifyAllProductsHaveStatus(String expectedStatus) {
        try {
            wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(allProductStatusPath));
            List<WebElement> statusElements = driver.findElements(allProductStatusPath);

            if (statusElements.isEmpty()) {
                System.out.println("No status elements found");
                return false;
            }

            boolean allMatch = true;
            for (WebElement statusElement : statusElements) {
                String actualStatus = statusElement.getText().trim();
                System.out.println("Product status: " + actualStatus);

                if (!actualStatus.equalsIgnoreCase(expectedStatus)) {
                    System.out.println("Status mismatch: Expected '" + expectedStatus + "' but found '" + actualStatus + "'");
                    allMatch = false;
                }
            }

            return allMatch;
        } catch (Exception e) {
            System.out.println("Error verifying product status: " + e.getMessage());
            return false;
        }
    }

    // Count products by status
    public int countProductsByStatus(String status) {
        try {
            By statusPath = By.xpath("//span[@class='truncate' and text()='" + status + "']");
            List<WebElement> statusElements = driver.findElements(statusPath);
            int count = statusElements.size();
            System.out.println("Products with status '" + status + "': " + count);
            return count;
        } catch (Exception e) {
            System.out.println("Error counting products by status: " + e.getMessage());
            return 0;
        }
    }
}