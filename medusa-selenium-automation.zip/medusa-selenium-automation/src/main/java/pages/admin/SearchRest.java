package pages.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import utility.HOOKS;

import java.util.List;

public class SearchRest extends HOOKS {

    By productsButtonPath = By.xpath("//a[@href='/app/products'] ");
    By searchFieldPath = By.name("q");
    By productTitlePath = By.xpath("//span[@title='Medusa Sweatshirt']");
    By allProductTitlesPath = By.xpath("//td[contains(@class, 'sticky')]//span[@title][@class='truncate']");

    public void clickProductsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(productsButtonPath));
        WebElement productsButton = driver.findElement(productsButtonPath);
        productsButton.click();
    }

    public void enterSearchQuery(String query) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchFieldPath));
        WebElement searchField = driver.findElement(searchFieldPath);
        searchField.clear(); // Clear first just in case
        searchField.sendKeys(query);

    }

    public void clearSearch() throws InterruptedException {
        WebElement searchField = wait.until(ExpectedConditions.visibilityOfElementLocated(searchFieldPath));
        String selectAll = Keys.chord(Keys.CONTROL, "a");
        searchField.sendKeys(selectAll);
        searchField.sendKeys(Keys.DELETE);

    }

    public boolean isProductDisplayed(String productName) {
        try {
            By specificProductPath = By.xpath("//span[@title='" + productName + "']");
            wait.until(ExpectedConditions.presenceOfElementLocated(specificProductPath));
            WebElement product = driver.findElement(specificProductPath);
            return product.isDisplayed();
        } catch (Exception e) {
            System.out.println("Product '" + productName + "' not found: " + e.getMessage());
            return false;
        }
    }

    // Get count of displayed products
    public int getProductCount() {
        try {
            // Wait a bit for products
            wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(allProductTitlesPath));
            List<WebElement> products = driver.findElements(allProductTitlesPath);
            int count = products.size();
            System.out.println("Current product count: " + count);
            return count;
        } catch (Exception e) {
            System.out.println("Error getting product count: " + e.getMessage());
            return 0;
        }
    }

}
