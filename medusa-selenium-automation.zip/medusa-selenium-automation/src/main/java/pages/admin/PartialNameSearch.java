package pages.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import utility.HOOKS;

import java.util.ArrayList;
import java.util.List;

public class PartialNameSearch extends HOOKS {
    By productsButtonPath = By.xpath("//a[@href='/app/products']");
    By searchFieldPath = By.name("q");
    By allProductTitlesPath = By.xpath("//td[contains(@class, 'sticky')]//span[@title][@class='truncate']");

    public void clickProductsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(productsButtonPath));
        WebElement productsButton = driver.findElement(productsButtonPath);
        productsButton.click();
    }

    public void enterSearchQuery(String query)  {
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchFieldPath));
        WebElement searchField = driver.findElement(searchFieldPath);
        searchField.clear();
        searchField.sendKeys(query);
    }

    public List<String> getDisplayedProductNames() {
        try {
            wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(allProductTitlesPath));
            List<WebElement> productElements = driver.findElements(allProductTitlesPath);

            List<String> productNames = new ArrayList<>();
            for (WebElement element : productElements) {
                String title = element.getAttribute("title");
                if (title != null && !title.trim().isEmpty()) {
                    productNames.add(title.trim());
                }
            }

            System.out.println("Displayed products: " + productNames);
            return productNames;
        } catch (Exception e) {
            System.out.println("Error getting product names: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean verifyAllResultsContainQuery(String query) {
        List<String> displayedProducts = getDisplayedProductNames();

        if (displayedProducts.isEmpty()) {
            System.out.println("No products displayed after search");
            return false;
        }

        // Check if ALL products contain the query
        boolean allMatch = true;
        for (String productName : displayedProducts) {
            if (!productName.toLowerCase().contains(query.toLowerCase())) {
                System.out.println("Product '" + productName + "' does NOT contain '" + query + "'");
                allMatch = false;
            } else {
                System.out.println("Product '" + productName + "' contains '" + query);
            }
        }

        return allMatch;
    }

    public int countResultsContainingQuery(String query) {
        List<String> displayedProducts = getDisplayedProductNames();
        int matchCount = 0;

        for (String productName : displayedProducts) {
            if (productName.toLowerCase().contains(query.toLowerCase())) {
                matchCount++;
            }
        }

        System.out.println("Found " + matchCount + " products containing '" + query + "'");
        return matchCount;
    }
}
