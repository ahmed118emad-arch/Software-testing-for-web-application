package pages.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import utility.HOOKS;

public class AdminLoginPage extends HOOKS {
    By emailFieldPath = By.name("email");
    By passwordFieldPath = By.name("password");
    By loginButtonPath = By.xpath("//form/button");


    public void enterEmail(String email) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(emailFieldPath));
        WebElement emailField = driver.findElement(emailFieldPath);
        emailField.sendKeys(email);
    }

    public void enterPassword(String password) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(passwordFieldPath));
        WebElement passwordField = driver.findElement(passwordFieldPath);
        passwordField.sendKeys(password);
    }

    public void clickLoginButton() {
        wait.until(ExpectedConditions.elementToBeClickable(loginButtonPath));
        WebElement loginButton = driver.findElement(loginButtonPath);
        loginButton.click();
    }

}
