package admin;

import pages.admin.AdminLoginPage;
import utility.HOOKS;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.asserts.SoftAssert;

import java.time.Duration;

public class AdminBaseTest extends HOOKS {

    @BeforeMethod(alwaysRun = true)
    public void setUp(){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Omar Hatem\\Desktop\\Folders\\DEPI_Testing\\ChromeDriver\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        softAssert = new SoftAssert();
        driver.manage().window().maximize();
        driver.get("http://localhost:9000/app");
    }

    @AfterMethod
    public void finish() throws InterruptedException {
        Thread.sleep(5000);
        driver.quit();
    }
}
