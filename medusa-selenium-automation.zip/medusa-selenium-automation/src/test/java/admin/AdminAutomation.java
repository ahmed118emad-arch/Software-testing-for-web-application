package admin;

import pages.admin.*;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;


public class AdminAutomation extends AdminBaseTest {

    AdminLoginPage adminLoginPage = new AdminLoginPage();
    SearchProductByExactTitle searchProductByExactTitle = new SearchProductByExactTitle();
    CatalogSortingMultipleFeatureAvailabilty catalogSortingMultipleFeatureAvailabilty = new CatalogSortingMultipleFeatureAvailabilty();
    SearchRest searchRest = new SearchRest();
    PartialNameSearch partialNameSearch = new PartialNameSearch();
    FilterProductsByStatusDraft filterProductsByStatusDraft = new FilterProductsByStatusDraft();
    FilterProductsByStatusPublished filterProductsByStatusPublished = new FilterProductsByStatusPublished();
    SpecialCharSearchRoubustness specialCharSearchRoubustness = new SpecialCharSearchRoubustness();


    @BeforeMethod
    public void adminLogin() {
        adminLoginPage.enterEmail("omarhatemun11@gmail.com");
        adminLoginPage.enterPassword("omarhatem1");
        adminLoginPage.clickLoginButton();
    }

    @Test
    public void searchProductByExactTitle() {


        String expectedProductName = "Medusa Sweatshirt";
        searchProductByExactTitle.clickProductsButton();
        searchProductByExactTitle.enterSearchQuery(expectedProductName);

        softAssert.assertTrue(
                searchProductByExactTitle.isProductDisplayed(expectedProductName),
                "Product should be displayed"
        );

        softAssert.assertEquals(
                searchProductByExactTitle.getProductTitle(),
                expectedProductName,
                "Product title should match"
        );

        softAssert.assertAll();
    }

    @Test
    public void sortProductsByFeatureAvailability() throws InterruptedException {
        catalogSortingMultipleFeatureAvailabilty.clickProductsButton();
        catalogSortingMultipleFeatureAvailabilty.clickSortByDropdown();
        catalogSortingMultipleFeatureAvailabilty.selectFeatureAvailabilityOption();
        catalogSortingMultipleFeatureAvailabilty.selectFeatureAvailabilityOption2();


        // Verify products are sorted correctly
        boolean isSorted = catalogSortingMultipleFeatureAvailabilty.verifyProductsSortedByTitleDescending();
        softAssert.assertTrue(isSorted, "Products should be sorted by Title in descending order (Z to A)");

        // Verify at least some products are displayed
        int productCount = catalogSortingMultipleFeatureAvailabilty.getProductCount();
        softAssert.assertTrue(productCount > 0, "Should display at least one product");

        softAssert.assertAll();
    }

    @Test
    public void searchRest() throws InterruptedException{
        String expectedProductName = "Medusa Sweatshirt";

        searchRest.clickProductsButton();

        // Get initial product count
        int initialProductCount = searchRest.getProductCount();
        softAssert.assertTrue(initialProductCount > 0, "Should have products before search");

        // Search for the product
        searchRest.enterSearchQuery(expectedProductName);

        // Verify search results
        boolean productFound = searchRest.isProductDisplayed(expectedProductName);
        softAssert.assertTrue(productFound, "Product '" + expectedProductName + "' should be found in search results");

        int searchResultCount = searchRest.getProductCount();
        softAssert.assertTrue(searchResultCount > 0, "Should have at least one search result");
        softAssert.assertTrue(searchResultCount <= initialProductCount, "Search results should be filtered (less than or equal to initial count)");

        // Clear search and verify all products return
        searchRest.clearSearch();

        int finalProductCount = searchRest.getProductCount();
        softAssert.assertEquals(finalProductCount, initialProductCount, "After clearing search, all products should be displayed again");

        softAssert.assertAll();
    }

    @Test
    public void partialNameSearch()  {
        String partialQuery = "Sweat";

        partialNameSearch.clickProductsButton();
        partialNameSearch.enterSearchQuery(partialQuery);


        // Verify search found products containing the partial query
        int matchingProducts = partialNameSearch.countResultsContainingQuery(partialQuery);
        softAssert.assertTrue(matchingProducts >= 2, "Should find at least 2 products containing '" + partialQuery + "' (expected: Sweatshirt, Sweatpants)");

        // Verify all results contain the search query
        boolean allMatch = partialNameSearch.verifyAllResultsContainQuery(partialQuery);
        softAssert.assertTrue(allMatch, "All search results should contain '" + partialQuery + "'");

        softAssert.assertAll();
    }

    @Test
    public void filterProductsByStatusDraft()  {
        filterProductsByStatusDraft.clickProductsButton();

        // Get initial count
        int initialProductCount = filterProductsByStatusDraft.getProductCount();
        softAssert.assertTrue(initialProductCount > 0, "Should have products before filtering");

        // Apply Draft filter
        filterProductsByStatusDraft.clickAddFilter();
        filterProductsByStatusDraft.selectStatusFilter();
        filterProductsByStatusDraft.selectDraftStatus();


        // Verify filtered results
        int draftCount = filterProductsByStatusDraft.countProductsByStatus("Draft");
        softAssert.assertTrue(draftCount > 0, "Should find at least one Draft product");

        int filteredProductCount = filterProductsByStatusDraft.getProductCount();
        softAssert.assertTrue(filteredProductCount > 0, "Should display draft products");
        softAssert.assertTrue(filteredProductCount < initialProductCount, "Filtered count (" + filteredProductCount + ") should be less than initial count (" + initialProductCount + ")");

        // Verify ALL displayed products have Draft status
        boolean allAreDraft = filterProductsByStatusDraft.verifyAllProductsHaveStatus("Draft");
        softAssert.assertTrue(allAreDraft, "All displayed products should have Draft status");

        softAssert.assertAll();
    }

    @Test
    public void filterProductsByStatusPublished()  {
        filterProductsByStatusPublished.clickProductsButton();

        // Get initial count
        int initialProductCount = filterProductsByStatusPublished.getProductCount();
        softAssert.assertTrue(initialProductCount > 0, "Should have products before filtering");

        // Apply Published filter
        filterProductsByStatusPublished.clickAddFilter();
        filterProductsByStatusPublished.selectStatusFilter();
        filterProductsByStatusPublished.selectPublishedStatus();

        // Verify filtered results
        int publishedCount = filterProductsByStatusPublished.countProductsByStatus("Published");
        softAssert.assertTrue(publishedCount > 0, "Should find at least one Published product");

        int filteredProductCount = filterProductsByStatusPublished.getProductCount();
        softAssert.assertTrue(filteredProductCount > 0, "Should display published products");
        softAssert.assertTrue(filteredProductCount < initialProductCount, "Filtered count (" + filteredProductCount + ") should be less than initial count (" + initialProductCount + ")");

        // Verify ALL displayed products have Published status
        boolean allArePublished = filterProductsByStatusPublished.verifyAllProductsHaveStatus("Published");
        softAssert.assertTrue(allArePublished, "All displayed products should have Published status");

        softAssert.assertAll();
    }

    @Test
    public void SpecialCharSearchRoubustness()  {
        String specialCharQuery = "@#$%^^&*";

        specialCharSearchRoubustness.clickProductsButton();

        // Get initial product count
        int initialProductCount = specialCharSearchRoubustness.getProductCount();
        softAssert.assertTrue(initialProductCount > 0, "Should have products before search");

        // Search with special characters
        specialCharSearchRoubustness.enterSearchQuery(specialCharQuery);

        // Verify the application handles special characters gracefully
        boolean pageLoaded = specialCharSearchRoubustness.isPageLoaded();
        softAssert.assertTrue(pageLoaded, "Page should still be functional after special character search");

        // Verify search completed (even if no results)
        boolean searchCompleted = specialCharSearchRoubustness.isSearchFieldAccessible();
        softAssert.assertTrue(searchCompleted, "Search field should still be accessible");

        // Get result count (likely 0 or same as initial)
        int resultCount = specialCharSearchRoubustness.getProductCount();
        System.out.println("Search results for '" + specialCharQuery + "': " + resultCount + " products");

        // Special characters should either return no results OR all results (no match)
        boolean validResultCount = (resultCount == 0) || (resultCount == initialProductCount);
        softAssert.assertTrue(validResultCount,
                "Special character search should return either 0 results (no match) or all results (" + initialProductCount + "), but got: " + resultCount);

        // Verify no error messages or crashes
        boolean hasErrorMessage = specialCharSearchRoubustness.hasErrorMessage();
        if (hasErrorMessage) {
            System.out.println("⚠ Error message displayed (this may be acceptable for invalid search)");
        }

        // Most important: verify the application didn't crash
        boolean appResponsive = specialCharSearchRoubustness.isApplicationResponsive();
        softAssert.assertTrue(appResponsive, "Application should remain responsive after special character search");

        softAssert.assertAll();
    }


}
