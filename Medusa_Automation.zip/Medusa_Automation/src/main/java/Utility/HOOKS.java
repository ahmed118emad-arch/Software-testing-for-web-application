package Utility;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import java.time.Duration;

public class HOOKS {
    public static WebDriver driver;
    public static SoftAssert softAssert;
    public static WebDriverWait wait;
}
