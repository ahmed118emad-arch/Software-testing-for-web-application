package Pages.Admin;

import Utility.HOOKS;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class Admin_Login_Page extends HOOKS {
    By emailTF_path = By.name("email");
    By passwordTF_path = By.name("password");
    By loginButton_path = By.xpath("//form/button");

    public void login(){
        enterEmail("araby@gmail.com");
        enterPassword("really_123superduper!!secret");
        clickLoginButton();
    }

    public void enterEmail(String email){
        wait.until(ExpectedConditions.visibilityOfElementLocated(emailTF_path));
        WebElement email_input=driver.findElement(emailTF_path);
        email_input.sendKeys(email);
    }

    public void enterPassword(String password){
        wait.until(ExpectedConditions.visibilityOfElementLocated(emailTF_path));
        WebElement password_input=driver.findElement(passwordTF_path);
        password_input.sendKeys(password);
    }

    public void clickLoginButton(){
        wait.until(ExpectedConditions.elementToBeClickable(loginButton_path));
        driver.findElement(loginButton_path).click();
    }

}
