package Pages.Admin;

import Utility.HOOKS;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Admin_OrdersDashboard_Page extends HOOKS {

    By filterOrdersButton_Path = By.id("filters_menu_trigger");
    By orderTableHeaders_Path = By.cssSelector("tr.bg-ui-bg-base th");
    By firstOrder_Path = By.cssSelector("a[data-row-link][href*='order_01KB2ZDRF848QGQ92FT4VPGDSR']");
    By createdDateFilterButton_Path = By.xpath("//div[@role='menuitem' and normalize-space()='Created']");
    By last30DaysDateFilter_Path = By.xpath("//button[normalize-space()='Last 30 days']");
    By anyWhereOnScreen_Path = By.className("dark");
    By dateText_Path = By.xpath("//a[@href='/app/orders/order_01KB2ZDRF848QGQ92FT4VPGDSR']//ancestor::td/following-sibling::td[1]//span");
    By firstOrderId_Path = By.cssSelector("td a[data-row-link='true'] span.truncate");
    By searchInput = By.cssSelector("input[name='q']");


    public ArrayList<String> viewOrdersTableHeaders() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(orderTableHeaders_Path));
        List<WebElement> orderTableHeaders = driver.findElements(orderTableHeaders_Path);

        ArrayList<String> ordersTableHeaders = new ArrayList<>();
        for (WebElement orderTableHeader : orderTableHeaders) {
            ordersTableHeaders.add(orderTableHeader.getText());
        }
        return ordersTableHeaders;
    }

    public WebElement viewOrdersTableContents() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstOrder_Path));
        return driver.findElement(firstOrder_Path);
    }

    public void clickOnOrder() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstOrder_Path));
        WebElement orderInTable = driver.findElement(firstOrder_Path);
        orderInTable.click();
    }

    public String viewOrdersAfterFilter() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(filterOrdersButton_Path));
        WebElement filterOrdersButton = driver.findElement(filterOrdersButton_Path);
        filterOrdersButton.click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(createdDateFilterButton_Path));
        WebElement createdDateFilterButton = driver.findElement(createdDateFilterButton_Path);
        createdDateFilterButton.click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(last30DaysDateFilter_Path));
        WebElement last30DaysDateFilter = driver.findElement(last30DaysDateFilter_Path);
        last30DaysDateFilter.click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(anyWhereOnScreen_Path));
        WebElement anyWhereOnScreen = driver.findElement(anyWhereOnScreen_Path);
        anyWhereOnScreen.click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(dateText_Path));
        WebElement dateText = driver.findElement(dateText_Path);

        return dateText.getText().trim();
    }

    public String getFirstOrderID(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstOrderId_Path));
        WebElement orderId = driver.findElement(firstOrderId_Path);
        String orderIdText = orderId.getText().trim().replace("#", "");
        return orderIdText;
    }

    public void searchByOrderID(String orderID){
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchInput));
        WebElement searchByOrderID = driver.findElement(searchInput);
        searchByOrderID.sendKeys(orderID);
    }
}
