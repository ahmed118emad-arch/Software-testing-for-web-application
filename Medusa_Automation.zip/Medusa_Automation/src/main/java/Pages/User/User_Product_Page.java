package Pages.User;

import Utility.HOOKS;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class User_Product_Page extends HOOKS {
    By product_size_Path = By.xpath("//button[text()='M']");
    By addToCartButton_Path = By.cssSelector("button[data-testid='add-product-button']");
    By cartLink_Path = By.cssSelector("a[data-testid='nav-cart-link']");


    public void select_Product_size()
    {
        wait.until(ExpectedConditions.elementToBeClickable(product_size_Path));
        driver.findElement(product_size_Path).click();
    }

    public void add_to_cart()
    {
        wait.until(ExpectedConditions.elementToBeClickable(addToCartButton_Path));
        driver.findElement(addToCartButton_Path).click();
    }

    public int getCartSize() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cartLink_Path));
        WebElement cartLink = driver.findElement(cartLink_Path);
        String cartLinkText = cartLink.getText().trim();


        int cartSize = 0;
        if (cartLinkText.matches("Cart \\(\\d+\\)")) {
            cartSize = Integer.parseInt(cartLinkText.replaceAll("\\D+", ""));
        }

        return cartSize;
    }

    public void go_to_cart_page()
    {
        wait.until(ExpectedConditions.elementToBeClickable(cartLink_Path));

        driver.findElement(cartLink_Path).click();
    }
}
