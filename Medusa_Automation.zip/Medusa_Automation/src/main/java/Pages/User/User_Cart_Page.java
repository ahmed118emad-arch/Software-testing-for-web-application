package Pages.User;

import Utility.HOOKS;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class User_Cart_Page extends HOOKS {
    By checkoutButton_Path = By.xpath("//button[normalize-space(text())='Go to checkout']");

    public void goToCheckout() {
        wait.until(ExpectedConditions.elementToBeClickable(checkoutButton_Path));
        driver.findElement(checkoutButton_Path).click();
    }
}
