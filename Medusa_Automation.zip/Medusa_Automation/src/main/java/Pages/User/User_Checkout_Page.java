package Pages.User;

import Utility.HOOKS;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class User_Checkout_Page extends HOOKS {
    By firstnameTF_Path = By.cssSelector("input[data-testid='shipping-first-name-input']");
    By lastNameTF_Path = By.cssSelector("input[data-testid='shipping-last-name-input']");
    By addressTF_Path = By.cssSelector("input[data-testid='shipping-address-input'");
    By postalTF_Path = By.cssSelector("input[data-testid='shipping-postal-code-input']");
    By countryTF_Path = By.cssSelector("select[data-testid='shipping-country-select']");
    By spainOption_Path = By.xpath("//select[@data-testid='shipping-country-select']/option[@value='es']");
    By cityTF_Path = By.cssSelector("input[data-testid='shipping-city-input']");
    By promotionCodeLink_Path = By.cssSelector("button[data-testid='add-discount-button']");
    By submitButton_Path = By.cssSelector("button[data-testid='submit-address-button']");

    By standardShippingOption_Path = By.xpath("//span[@data-testid='delivery-option-radio' and .//span[text()='Standard Shipping'] and .//span[text()='€10.00']]");
    By continueToPayment_Path = By.xpath("//button[@data-testid='submit-delivery-option-button' and normalize-space(text())='Continue to payment']");
    By manualPayment_Path = By.xpath("//span[@data-headlessui-state and .//p[text()='Manual Payment'] and .//span[contains(text(),'For testing purposes only')]]");
    By continueToReview_Path = By.xpath("//button[@data-testid='submit-payment-button' and normalize-space(text())='Continue to review']");

    By placeOrder_Path = By.xpath("//button[@data-testid='submit-order-button' and normalize-space(text())='Place order']");


    public void enterCheckoutInfo(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstnameTF_Path));
        driver.findElement(firstnameTF_Path).sendKeys("Abdulrahman");
        driver.findElement(lastNameTF_Path).sendKeys("Ramadan");
        driver.findElement(addressTF_Path).sendKeys("3 Giza street");
        driver.findElement(postalTF_Path).sendKeys("12345");
        wait.until(ExpectedConditions.elementToBeClickable(countryTF_Path));
        driver.findElement(countryTF_Path).click();
        wait.until(ExpectedConditions.elementToBeClickable(spainOption_Path));
        driver.findElement(spainOption_Path).click();
        driver.findElement(cityTF_Path).sendKeys("Giza");
    }

    public void clickSubmitButton(){
        wait.until(ExpectedConditions.elementToBeClickable(submitButton_Path));
        driver.findElement(submitButton_Path).click();
    }

    public void clickContinueToPayment(){
        wait.until(ExpectedConditions.elementToBeClickable(standardShippingOption_Path));
        driver.findElement(standardShippingOption_Path).click();
        wait.until(ExpectedConditions.elementToBeClickable(continueToPayment_Path));
        driver.findElement(continueToPayment_Path).click();
    }


    public void clickContinueToReview(){
        wait.until(ExpectedConditions.elementToBeClickable(manualPayment_Path));
        driver.findElement(manualPayment_Path).click();
        wait.until(ExpectedConditions.elementToBeClickable(continueToReview_Path));
        driver.findElement(continueToReview_Path).click();
    }

    public void clickPlaceOrder(){
        wait.until(ExpectedConditions.elementToBeClickable(placeOrder_Path));
        driver.findElement(placeOrder_Path).click();
    }

}
