package Pages.User;

import Utility.HOOKS;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class User_Registeration_Page extends HOOKS {
    By firstNameInput     = By.cssSelector("input[data-testid='first-name-input']");
    By lastNameInput      = By.cssSelector("input[data-testid='last-name-input']");
    By emailInput         = By.cssSelector("input[data-testid='email-input']");
    By phoneInput         = By.cssSelector("input[data-testid='phone-input']");
    By passwordInput      = By.cssSelector("input[data-testid='password-input']");

    // Buttons
    By registerButton     = By.cssSelector("button[data-testid='register-button']");
    By signInLinkButton   = By.xpath("//span[contains(text(),'Already a member')]/button");


    public void enterFirstName(String firstName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameInput));
        driver.findElement(firstNameInput).sendKeys(firstName);
    }

    public void enterLastName(String lastName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lastNameInput));
        driver.findElement(lastNameInput).sendKeys(lastName);
    }

    public void enterEmail(String email) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(emailInput));
        driver.findElement(emailInput).sendKeys(email);
    }

    public void enterPhone(String phone) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(phoneInput));
        driver.findElement(phoneInput).sendKeys(phone);
    }

    public void enterPassword(String password) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(passwordInput));
        driver.findElement(passwordInput).sendKeys(password);
    }

    // Click Methods
    public void clickRegister() {
        wait.until(ExpectedConditions.elementToBeClickable(registerButton));
        driver.findElement(registerButton).click();
    }

    public void clickSignIn() {
        wait.until(ExpectedConditions.elementToBeClickable(signInLinkButton));
        driver.findElement(signInLinkButton).click();
    }

    public void signUp(String firstName, String lastName, String email, String phone, String password) {
        enterFirstName(firstName);
        enterLastName(lastName);
        enterEmail(email);
        enterPhone(phone);
        enterPassword(password);
        clickRegister();
    }

}
