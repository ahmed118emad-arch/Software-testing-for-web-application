package Pages.User;

import Utility.HOOKS;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.ArrayList;
import java.util.List;

public class User_Confirmation_Page extends HOOKS {
    By h1Element = By.cssSelector("h1.font-sans.font-medium.h1-core");

    public String getText(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(h1Element));
        WebElement spansList = driver.findElement(h1Element);
        List<WebElement> spans = spansList.findElements(By.tagName("span"));
        String texts = "";
        for (WebElement span : spans) {
            texts += span.getText();
        }
        return texts;
    }
}
