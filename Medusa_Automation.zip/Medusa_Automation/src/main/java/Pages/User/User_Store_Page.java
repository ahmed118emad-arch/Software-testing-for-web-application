package Pages.User;

import Utility.HOOKS;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class User_Store_Page extends HOOKS {
    By product_Path = By.cssSelector("img[src*='sweatshirt-vintage-front.png']");

    public void select_Product()
    {
        wait.until(ExpectedConditions.elementToBeClickable(product_Path));
        driver.findElement(product_Path).click();
    }


}
