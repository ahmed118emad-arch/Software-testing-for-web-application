package Pages.User;

import Utility.HOOKS;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;


public class User_Account_Page extends HOOKS {
    By welcomeMessage_Path = By.cssSelector("span[data-testid='welcome-message']");
    By menu_Path = By.cssSelector("button[data-testid='nav-menu-button']");
    By store_Path = By.cssSelector("a[data-testid='store-link']");
    By orders_Path = By.cssSelector("div[data-testid='account-nav'] a[data-testid='orders-link']");
    By noOrdersMessage_Path = By.cssSelector("div[data-testid='no-orders-container'] p");
    By orderId_Path = By.cssSelector("span[data-testid='order-display-id']");
    By ordersCard_Path = By.cssSelector("div[data-testid='order-card']");



    public String viewWelcomeMessage()
    {
        wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage_Path));
        WebElement welcomeMessage=driver.findElement(welcomeMessage_Path);
        return welcomeMessage.getText();
    }

    public void goToStore(){
        wait.until(ExpectedConditions.elementToBeClickable(menu_Path));
        driver.findElement(menu_Path).click();
        wait.until(ExpectedConditions.elementToBeClickable(store_Path));
        driver.findElement(store_Path).click();
    }

    public void goToOrders(){
        wait.until(ExpectedConditions.elementToBeClickable(orders_Path));
        driver.findElement(orders_Path).click();
    }

    public String getNoOrdersMessage()
    {
        wait.until(ExpectedConditions.elementToBeClickable(noOrdersMessage_Path));
        String noOrdersMessage=driver.findElement(noOrdersMessage_Path).getText();

        return noOrdersMessage;
    }

    public String getOrderId(){
        wait.until(ExpectedConditions.elementToBeClickable(orderId_Path));
        String orderId=driver.findElement(orderId_Path).getText();
        return orderId;
    }

    public List<WebElement> getOrders(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(ordersCard_Path));
        List<WebElement> orders=driver.findElements(ordersCard_Path);
        return orders;
    }

}
