package Pages.User;

import Utility.HOOKS;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class User_Login_Page extends HOOKS {
    By emailTF_path = By.name("email");
    By passwordTF_path = By.name("password");
    By loginButton_path = By.xpath("//form/button");
    By errorMessage_Path = By.className("pt-2");
    By passwordEye_path = By.cssSelector("svg[width='20'][height='20'][viewBox='0 0 20 20'][fill='none']");
    By passwordInput_Path = By.cssSelector("input[data-testid='password-input']");
    By joinUsButton = By.cssSelector("button[data-testid='register-button']");


    public void login(String email, String password){
        enterEmail(email);
        enterPassword(password);
        clickLoginButton();
    }

    public void enterEmail(String email){
        wait.until(ExpectedConditions.visibilityOfElementLocated(emailTF_path));
        WebElement email_input=driver.findElement(emailTF_path);
        email_input.sendKeys(email);
    }

    public void enterPassword(String password){
        wait.until(ExpectedConditions.visibilityOfElementLocated(emailTF_path));
        WebElement password_input=driver.findElement(passwordTF_path);
        password_input.sendKeys(password);
    }

    public void clickLoginButton(){
        wait.until(ExpectedConditions.elementToBeClickable(loginButton_path));
        driver.findElement(loginButton_path).click();
    }

    public String getErrorMessage(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(errorMessage_Path));
        return driver.findElement(errorMessage_Path).getText();
    }

    public String toggleShowHidePassword(){
        wait.until(ExpectedConditions.elementToBeClickable(passwordEye_path));
        wait.until(ExpectedConditions.elementToBeClickable(passwordInput_Path));

        WebElement passwordInput = driver.findElement(passwordInput_Path);

        driver.findElement(passwordEye_path).click();

        String type = driver.findElement(passwordInput_Path).getAttribute("type");
        return type;
    }

    public void clickJoinUs() {
        wait.until(ExpectedConditions.elementToBeClickable(joinUsButton));
        driver.findElement(joinUsButton).click();
    }


}
