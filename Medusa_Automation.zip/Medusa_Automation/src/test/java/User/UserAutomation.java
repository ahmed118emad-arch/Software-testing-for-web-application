package User;

import Pages.User.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

public class UserAutomation extends UserBaseTest{
    User_Login_Page user_login_page=new User_Login_Page();
    User_Account_Page user_account_page=new User_Account_Page();
    User_Store_Page user_store_page=new User_Store_Page();
    User_Product_Page user_product_page=new User_Product_Page();
    User_Cart_Page user_cart_page=new User_Cart_Page();
    User_Checkout_Page user_checkout_page=new User_Checkout_Page();
    User_Confirmation_Page  user_confirmation_page=new User_Confirmation_Page();
    User_Registeration_Page  user_registeration_page=new User_Registeration_Page();


    @Test
    public void valid_Login__TC_Authentication_046()
    {
        user_login_page.enterEmail("aram@gmail.com");
        user_login_page.enterPassword("AR1462r789!");
        user_login_page.clickLoginButton();
        softAssert.assertEquals(user_account_page.viewWelcomeMessage(),"Hello Abdulrahman");
        softAssert.assertAll();
    }

    @Test
    public void TC_047_InvalidPassword() {
        user_login_page.login("aram@gmail.com","wrooong1!");
        String errorMessage = user_login_page.getErrorMessage();
        softAssert.assertEquals(errorMessage,"Error: Invalid email or password");
        softAssert.assertAll();
    }

    @Test
    public void locked_account_after_5_failed_attempts__TC_Authentication_052()
    {
        for(int i=0;i<5;i++){
            user_login_page.enterEmail("wrong@gmail.com");
            user_login_page.enterPassword("wrong123");
            user_login_page.clickLoginButton();
        }
        softAssert.assertEquals(user_login_page.getErrorMessage(),"Account locked; further attempts blocked");
        softAssert.assertAll();
    }

    @Test
    public void show_Hide_password_toggle__TC_Password_Validation_078()
    {
        user_login_page.enterPassword("password");
        String hideOrShow = user_login_page.toggleShowHidePassword();
        String showOrHide = user_login_page.toggleShowHidePassword();

        softAssert.assertNotEquals(hideOrShow,showOrHide);
        softAssert.assertAll();
    }

    @Test
    public void TC_001_ValidRegistration() {
        user_login_page.clickJoinUs();
        user_registeration_page.signUp("Ahmed", "Emad", "test7447@example.com", "01234567890", "Test@1234");
        softAssert.assertEquals(user_account_page.viewWelcomeMessage(), "Hello Ahmed");
        softAssert.assertAll();
    }

    @Test
    public void TC_002_EmptyForm() {
        user_login_page.clickJoinUs();
        String currentUrl = driver.getCurrentUrl();
        user_registeration_page.signUp("", "", "", "", "");
        try {
            Thread.sleep(5000); // 1 second
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        softAssert.assertEquals(driver.getCurrentUrl(), currentUrl, "The page should not redirect when form is empty");
        softAssert.assertAll();
    }

    @Test
    public void TC_008_NameMinInvalid() {
        user_login_page.clickJoinUs();
        user_registeration_page.signUp("A", "Emad", "ixzoip@example.com", "0121663318", "Test@1234");

        softAssert.assertFalse(user_account_page.viewWelcomeMessage().contains("Hello"));
        softAssert.assertAll();
    }

    @Test
    public void TC_020_InvalidEmail(){
        user_login_page.clickJoinUs();

        String currentUrl = driver.getCurrentUrl();

        user_registeration_page.signUp("John", "Doe", "invalidEmail", "0123456789", "ValidPass123!");

        try { Thread.sleep(5000); } catch (InterruptedException e) { e.printStackTrace(); }

        softAssert.assertEquals(driver.getCurrentUrl(), currentUrl, "The page should not redirect with an invalid email");
        softAssert.assertAll();
    }

    @Test
    public void TC_030_PhoneTooShort() {
        user_login_page.clickJoinUs();
        user_registeration_page.signUp("John", "Doe", "joteknouv@example.com", "123", "ValidPass123!");

        softAssert.assertFalse(user_account_page.viewWelcomeMessage().contains("Hello"));
        softAssert.assertAll();
    }

    @Test
    public void TC_039_PasswordTooShort() {
        user_login_page.clickJoinUs();
        user_registeration_page.signUp("John", "Doe", "jdottt@example.com", "0123456789", "123");

        softAssert.assertFalse(user_account_page.viewWelcomeMessage().contains("Hello"));
        softAssert.assertAll();
    }


    @Test
    public void Add_item_to_cart__TC_cart_106(){
        user_login_page.login("oh@gmail.com","oh123");
        user_account_page.goToStore();
        user_store_page.select_Product();
        int initialCartSize = user_product_page.getCartSize();
        user_product_page.select_Product_size();
        user_product_page.add_to_cart();
        wait.until(driver -> user_product_page.getCartSize() == initialCartSize + 1);
        int newCartSize = user_product_page.getCartSize();
        softAssert.assertEquals(newCartSize, initialCartSize + 1, "Cart size did not increment correctly!");
        softAssert.assertAll();
    }

    @Test
    public void verify_successful_order_placement_with_valid_checkout__TC_checkout_168(){
        user_login_page.login("oh@gmail.com","oh123");
        user_account_page.goToStore();
        user_store_page.select_Product();
        int initialCartSize = user_product_page.getCartSize();
        user_product_page.select_Product_size();
        user_product_page.add_to_cart();
        wait.until(driver -> user_product_page.getCartSize() == initialCartSize + 1);
        user_product_page.go_to_cart_page();
        user_cart_page.goToCheckout();
        user_checkout_page.enterCheckoutInfo();
        user_checkout_page.clickSubmitButton();
        user_checkout_page.clickContinueToPayment();
        user_checkout_page.clickContinueToReview();
        user_checkout_page.clickPlaceOrder();
        softAssert.assertEquals(user_confirmation_page.getText(), "Thank you!Your order was placed successfully.");
        softAssert.assertAll();
    }

    @Test
    public void View_empty_order_history__TC_OM_CUST_302(){
        user_login_page.login("r2@test.com","r2");
        user_account_page.goToOrders();
        softAssert.assertTrue(user_account_page.getNoOrdersMessage().contains("You don't have any orders"));
        softAssert.assertAll();
    }

    @Test
    public void View_single_order_history__TC_OM_CUST_303(){
        user_login_page.login("r1@test.com","r1");
        user_account_page.goToOrders();
        softAssert.assertEquals(user_account_page.getOrderId(), "2");
        softAssert.assertAll();
    }

    @Test
    public void View_multiple_orders__TC_OM_CUST_304(){
        user_login_page.login("oh@gmail.com","oh123");
        user_account_page.goToOrders();
        List<WebElement> orders = user_account_page.getOrders();
        softAssert.assertTrue(orders.size()>=5);
        softAssert.assertAll();
    }
}
