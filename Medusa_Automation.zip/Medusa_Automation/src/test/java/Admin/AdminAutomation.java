package Admin;

import Pages.Admin.Admin_Login_Page;
import Pages.Admin.Admin_OrdersDashboard_Page;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;

public class AdminAutomation extends AdminBaseTest {

    Admin_Login_Page admin_login_page = new Admin_Login_Page();
    Admin_OrdersDashboard_Page admin_ordersDashboard_page = new Admin_OrdersDashboard_Page();


    @BeforeMethod
    public void adminLogin() {
        admin_login_page.login();
    }

    @Test
    public void admin_dashboard_orders_view__TC_OM_ADMIN_327() {
        ArrayList<String> ordersTableHeaders = new ArrayList<>();

        ordersTableHeaders.add("Order");
        ordersTableHeaders.add("Date");
        ordersTableHeaders.add("Customer");
        ordersTableHeaders.add("Sales Channel");
        ordersTableHeaders.add("Payment");
        ordersTableHeaders.add("Fulfillment");
        ordersTableHeaders.add("Order Total");
        ordersTableHeaders.add("");

        ArrayList<String> actualHeaders = new ArrayList<>();
        for(String order:admin_ordersDashboard_page.viewOrdersTableHeaders()){
            actualHeaders.add(order);
        }

        softAssert.assertEquals(actualHeaders, ordersTableHeaders);
        softAssert.assertAll();
    }

    @Test
    public void view_all_orders_no_filters__TC_OM_ADMIN_328() {
        softAssert.assertNotEquals(admin_ordersDashboard_page.viewOrdersTableContents(), null);
        softAssert.assertAll();
    }


    @Test
    public void filter_orders_by_date_range_specific_dates__TC_OM_ADMIN_345() {
        String dateString = admin_ordersDashboard_page.viewOrdersAfterFilter();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy", Locale.ENGLISH);
        LocalDate orderDate = LocalDate.parse(dateString, formatter);

        LocalDate today = LocalDate.now();

        boolean isWithin30Days = !orderDate.isBefore(today.minusDays(30));

        softAssert.assertTrue(isWithin30Days, "Order date is not within the last 30 days! Order date was: " + orderDate);
        softAssert.assertAll();
    }

    @Test
    public void search_orders_by_exact_order_ID__TC_OM_ADMIN_356(){
        String orderId = admin_ordersDashboard_page.getFirstOrderID();
        admin_ordersDashboard_page.searchByOrderID(orderId);
        softAssert.assertEquals(admin_ordersDashboard_page.getFirstOrderID(), orderId);
        softAssert.assertAll();
    }

}
